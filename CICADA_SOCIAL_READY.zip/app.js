// Launch
setTimeout(()=>{
 document.getElementById('splash').style.display='none';
 document.getElementById('app').classList.remove('hidden');
 showFeed();
},2000);

let posts=[
 {user:'Admin',text:'Welcome to CICADA Social'},
 {user:'CICADA AI',text:'Your privacy-first AI network'}
];

function showFeed(){
 const c=document.getElementById('content');
 c.innerHTML=posts.map(p=>`<div class="card"><b>${p.user}</b><p>${p.text}</p></div>`).join('');
}

function showCreate(){
 const c=document.getElementById('content');
 c.innerHTML=`
 <h3>Create Post</h3>
 <textarea id="postText"></textarea>
 <button class="action" onclick="generateAI()">AI Generate</button>
 <button class="action" onclick="publish()">Publish</button>`;
}

function generateAI(){
 document.getElementById('postText').value=
 '🔥 AI generated content for CICADA users';
}

function publish(){
 const text=document.getElementById('postText').value;
 posts.unshift({user:'You',text});
 showFeed();
}

function showChat(){
 document.getElementById('content').innerHTML=
 '<h3>Chat</h3><p>Encrypted chat module ready</p>';
}

function showProfile(){
 document.getElementById('content').innerHTML=
 '<h3>Profile</h3><p>User settings & privacy</p>';
}
